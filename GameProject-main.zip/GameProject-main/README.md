Please install NPM and these following libraries before running the project: 

npm install @fortawesome/react-fontawesome styled-components @fortawesome/free-solid-svg-icons

for these imports: 

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import styled, { keyframes } from 'styled-components';
import { faQuestionCircle, faGamepad, faPlayCircle, faTrophy } from '@fortawesome/free-solid-svg-icons';
